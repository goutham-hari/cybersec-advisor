import { DeckData } from "../types";

export const initialDeck: DeckData = {
  title: "CyberSec Advisor",
  subtitle: "A Local, Retrieval-Augmented Knowledge Assistant for Cybersecurity Research",
  slides: [
    {
      id: "slide-1",
      title: "CyberSec Advisor",
      subtitle: "A Local, Retrieval-Augmented Knowledge Assistant for Cybersecurity Research",
      content: [
        " [Your Name / Team Name]",
        "[Institution / Organization] — [Date]"
      ],
      visual: "Clean centered title card, dark navy background with a single mint/teal shield icon.",
      script: "Good morning/afternoon everyone. Today, I am excited to present CyberSec Advisor. In the world of cybersecurity, the volume of information is staggering, but the ability to retrieve a specific answer from a trusted source is surprisingly difficult. We have built a Local, Retrieval-Augmented Knowledge Assistant designed specifically to turn static cybersecurity libraries into an interactive, cited, and highly accurate research tool.",
      layoutType: "title"
    },
    {
      id: "slide-2",
      title: "Agenda / Overview",
      subtitle: "Set clear expectations for what the audience will learn in the next few minutes.",
      content: [
        "The problem: scattered, hard-to-search security knowledge",
        "Our solution: a retrieval-augmented chatbot grounded in real books",
        "How it works: architecture and key technical features",
        "What we built and validated: results and evaluation",
        "What's next: challenges and future scope"
      ],
      visual: "Simple 5-item numbered list or a horizontal roadmap/timeline graphic with icons per section.",
      script: "To give you a roadmap of this presentation: I’ll start by defining the specific pain point we are addressing—the fragmentation of security knowledge. Then, I will walk you through our proposed solution and the technical architecture of the RAG pipeline. I’ll dive into the specific methodology—particularly how we handle search—and then share the quantitative results of our evaluation. Finally, I’ll discuss the engineering challenges we faced and where this project goes from here.",
      layoutType: "agenda"
    },
    {
      id: "slide-3",
      title: "Problem Statement / Background",
      subtitle: "Security knowledge is fragmented across dozens of sources, and generic AI chatbots can't fill that gap reliably.",
      content: [
        "Security practitioners rely on dozens of scattered technical references",
        "Manually searching PDFs for the right methodology is slow",
        "General-purpose AI chatbots don't cite sources or ground answers in your material",
        "Result: knowledge exists, but it's not efficiently accessible"
      ],
      visual: "Icon row showing 'scattered books/PDFs' converging toward a big question mark.",
      script: "If you’ve ever done deep security research, you know the struggle. Technical knowledge is scattered across hundreds of pages of PDFs, textbooks, and whitepapers. When you need a specific methodology or a detail on a protocol, you're often stuck manually Ctrl-F-ing through ten different documents. Now, we have general-purpose AI chatbots, but they have two major flaws for security work: first, they 'hallucinate' technical details, and second, they are 'black boxes'—they don't tell you exactly which page of which book their answer came from. In cybersecurity, an unverified answer is a dangerous answer.",
      layoutType: "standard"
    },
    {
      id: "slide-4",
      title: "Proposed Solution / Project Architecture",
      subtitle: "CyberSec Advisor turns a personal book library into a searchable, cited AI assistant using a retrieval-augmented generation (RAG) pipeline.",
      content: [
        "PDF books → extracted, chunked, and indexed locally",
        "Hybrid retrieval: semantic (vector) search + keyword (BM25) search",
        "Retrieved passages + question sent to an LLM for grounded answers",
        "Every answer cites the exact book and page it came from"
      ],
      visual: "Horizontal flowchart: PDF Library → Chunk & Extract → Local Embeddings → Vector Store → Hybrid Retrieval → LLM → Cited Answer.",
      script: "Our solution is CyberSec Advisor. Instead of relying on the LLM's internal memory, we use a Retrieval-Augmented Generation, or RAG, pipeline. Here is how the data flows: We take a library of PDF books and break them into manageable chunks. These chunks are converted into vectors—mathematical representations of meaning—and stored in a local vector database. When a user asks a question, the system doesn't just 'guess.' It searches the library for the most relevant passages, feeds those specific excerpts to the LLM, and instructs the model to answer only based on that provided text. The result is a grounded answer that includes a direct citation to the source book and page.",
      layoutType: "architecture"
    },
    {
      id: "slide-5",
      title: "Key Features / Methodology",
      subtitle: "The system combines several deliberate technical choices to maximize accuracy while keeping cost at zero.",
      content: [
        "Hybrid search (vector + BM25) merged via Reciprocal Rank Fusion",
        "Multi-turn conversation memory for natural follow-up questions",
        "Local embeddings and local vector storage — zero infrastructure cost",
        "Explicit responsible-use scope built into the system prompt"
      ],
      visual: "Four-quadrant grid, one icon + short label per feature (search icon, chat-bubble icon, dollar-sign icon, shield icon).",
      script: "To make this production-ready, we implemented several key technical choices. First, we realized that 'Semantic Search' (vector search) is great for concepts, but terrible for specific strings—like a CVE ID or a specific registry key. To solve this, we implemented Hybrid Search. We combine vector search with BM25 keyword search and merge them using Reciprocal Rank Fusion. This ensures we catch both the 'meaning' and the 'exact keywords.' Additionally, we’ve ensured the system is entirely local-first in terms of storage to keep infrastructure costs at zero, and we’ve implemented multi-turn memory, allowing the user to ask follow-up questions without losing the context of the research session.",
      layoutType: "features"
    },
    {
      id: "slide-6",
      title: "Results / Implementation Highlights",
      subtitle: "We didn't just build this — we measured it, using a real evaluation methodology.",
      content: [
        "Built and tested a labeled evaluation set of real security questions",
        "Measured Hit Rate@k, Precision@k, and Mean Reciprocal Rank (MRR)",
        "Compared vector-only vs. BM25-only vs. hybrid retrieval",
        "Hybrid search recovered exact-match content (e.g., CVE references) that vector search alone missed"
      ],
      visual: "Bar chart comparing Hit Rate@k across the three retrieval methods (vector-only, BM25-only, hybrid).",
      script: "We believe that 'it seems to work' isn't a technical metric. To validate the system, we built a labeled evaluation dataset consisting of real security questions and their corresponding ground-truth documents. We measured the system using Hit Rate, Precision, and Mean Reciprocal Rank (MRR). As you can see from the data, there was a significant jump in performance when we moved from vector-only search to hybrid search. Specifically, the hybrid approach successfully recovered technical references and CVEs that the semantic search completely missed. This proves that for technical domains, hybrid retrieval is a necessity, not an option.",
      layoutType: "results"
    },
    {
      id: "slide-7",
      title: "Challenges & Future Scope",
      subtitle: "Building on modest, zero-cost infrastructure required real engineering tradeoffs — and there's a clear path to extend the system further.",
      content: [
        "Challenge: free-tier LLM API quotas required careful model selection",
        "Challenge: pure vector search missed exact technical strings — solved via hybrid search",
        "Future: reranking step to further improve retrieval precision",
        "Future: expanding the source library and quantitative evaluation coverage"
      ],
      visual: "Two-column 'Challenges Solved' vs. 'What's Next' layout with checkmarks and arrow icons.",
      script: "Of course, building this on a zero-cost budget came with challenges. We had to be very strategic with LLM API quotas, which required us to optimize our prompt lengths and chunk sizes. Looking ahead, we see two primary paths for growth. First, we want to implement a Cross-Encoder Reranker. While our hybrid search finds the top 10 documents, a reranker would more accurately pick the top 3, further reducing noise for the LLM. Second, we plan to expand our library and create a more comprehensive benchmarking suite to test the system across different security domains, from forensics to cloud security.",
      layoutType: "roadmap"
    },
    {
      id: "slide-8",
      title: "Conclusion",
      subtitle: "CyberSec Advisor proves that a rigorous, cited, and evaluated AI research assistant can be built entirely on free infrastructure.",
      content: [
        "A fully local-first RAG pipeline, zero recurring cost",
        "Citation-backed answers grounded in real, trusted reference material",
        "Validated with real retrieval metrics, not just qualitative impressions",
        "A responsibly scoped tool built for legitimate security education and practice"
      ],
      visual: "Centered closing graphic — shield icon with a short tagline ('Local library. Grounded answers. Zero cost.').",
      script: "In summary, CyberSec Advisor demonstrates that you don't need a massive budget or a proprietary dataset to build a professional research tool. By combining a local-first RAG pipeline with hybrid retrieval and a rigorous evaluation framework, we've created a tool that is grounded, cited, and validated. It transforms a static library into a living knowledge base, ensuring that the right information is always just one question away.",
      layoutType: "conclusion"
    },
    {
      id: "slide-9",
      title: "Q&A",
      subtitle: "Invite discussion and questions.",
      content: [
        "Thank you",
        "Questions & discussion",
        "[Your contact / GitHub repo link]"
      ],
      visual: "Minimal slide — just the heading 'Questions?' centered.",
      script: "Thank you for your time. I’ve included the link to the GitHub repository on this slide. I would now love to take any questions you may have regarding the architecture, the evaluation metrics, or the implementation.",
      layoutType: "qa"
    }
  ]
};
