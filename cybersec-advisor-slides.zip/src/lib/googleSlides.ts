import { DeckData } from "../types";

export interface GoogleSlidesExportResult {
  presentationId: string;
  presentationUrl: string;
}

export async function createGoogleSlidesPresentation(
  deck: DeckData,
  accessToken: string
): Promise<GoogleSlidesExportResult> {
  // 1. Create a new presentation
  const createRes = await fetch("https://slides.googleapis.com/v1/presentations", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      title: deck.title || "CyberSec Advisor Presentation",
    }),
  });

  if (!createRes.ok) {
    const errorData = await createRes.json().catch(() => ({}));
    throw new Error(
      errorData?.error?.message || `Failed to create presentation (${createRes.status})`
    );
  }

  const presentation = await createRes.json();
  const presentationId = presentation.presentationId;

  // Initial default slide ID if created
  const initialSlideId = presentation.slides?.[0]?.objectId;

  // Prepare batch requests
  const requests: any[] = [];

  // Delete initial default slide if it exists
  if (initialSlideId) {
    requests.push({
      deleteObject: { objectId: initialSlideId },
    });
  }

  // Iterate over deck slides
  deck.slides.forEach((slide, idx) => {
    const slideId = `slide_custom_${idx + 1}`;
    const titleBoxId = `title_box_${idx + 1}`;
    const subBoxId = `sub_box_${idx + 1}`;
    const contentBoxId = `content_box_${idx + 1}`;
    const visualBoxId = `visual_box_${idx + 1}`;

    // Create blank slide
    requests.push({
      createSlide: {
        objectId: slideId,
        insertionIndex: idx,
        slideLayoutType: "BLANK",
      },
    });

    // Set background color (#0B0F14)
    requests.push({
      updatePageProperties: {
        objectId: slideId,
        pageProperties: {
          pageBackgroundFill: {
            solidFill: {
              color: {
                rgbColor: { red: 11 / 255, green: 15 / 255, blue: 20 / 255 },
              },
            },
          },
        },
        fields: "pageBackgroundFill.solidFill.color",
      },
    });

    if (idx === 0) {
      // TITLE SLIDE LAYOUT
      // Title Box (Centered)
      requests.push({
        createShape: {
          objectId: titleBoxId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: slideId,
            size: {
              width: { magnitude: 9000000, unit: "EMU" }, // 10 inches
              height: { magnitude: 1200000, unit: "EMU" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 1200000,
              translateY: 1500000,
              unit: "EMU",
            },
          },
        },
      });

      requests.push({
        insertText: {
          objectId: titleBoxId,
          text: slide.title,
        },
      });

      requests.push({
        updateTextStyle: {
          objectId: titleBoxId,
          style: {
            fontFamily: "Georgia",
            fontSize: { magnitude: 40, unit: "PT" },
            bold: true,
            foregroundColor: {
              opaqueColor: {
                rgbColor: { red: 61 / 255, green: 220 / 255, blue: 151 / 255 }, // Mint
              },
            },
          },
          fields: "fontFamily,fontSize,bold,foregroundColor",
        },
      });

      // Subtitle Box
      requests.push({
        createShape: {
          objectId: subBoxId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: slideId,
            size: {
              width: { magnitude: 9000000, unit: "EMU" },
              height: { magnitude: 1000000, unit: "EMU" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 1200000,
              translateY: 2800000,
              unit: "EMU",
            },
          },
        },
      });

      requests.push({
        insertText: {
          objectId: subBoxId,
          text: slide.subtitle,
        },
      });

      requests.push({
        updateTextStyle: {
          objectId: subBoxId,
          style: {
            fontFamily: "Arial",
            fontSize: { magnitude: 20, unit: "PT" },
            italic: true,
            foregroundColor: {
              opaqueColor: {
                rgbColor: { red: 140 / 255, green: 160 / 255, blue: 175 / 255 }, // Muted
              },
            },
          },
          fields: "fontFamily,fontSize,italic,foregroundColor",
        },
      });

      // Content Box (Team / Institution)
      if (slide.content && slide.content.length > 0) {
        requests.push({
          createShape: {
            objectId: contentBoxId,
            shapeType: "TEXT_BOX",
            elementProperties: {
              pageObjectId: slideId,
              size: {
                width: { magnitude: 9000000, unit: "EMU" },
                height: { magnitude: 1000000, unit: "EMU" },
              },
              transform: {
                scaleX: 1,
                scaleY: 1,
                translateX: 1200000,
                translateY: 4000000,
                unit: "EMU",
              },
            },
          },
        });

        requests.push({
          insertText: {
            objectId: contentBoxId,
            text: slide.content.join("\n"),
          },
        });

        requests.push({
          updateTextStyle: {
            objectId: contentBoxId,
            style: {
              fontFamily: "Arial",
              fontSize: { magnitude: 16, unit: "PT" },
              foregroundColor: {
                opaqueColor: {
                  rgbColor: { red: 231 / 255, green: 237 / 255, blue: 242 / 255 },
                },
              },
            },
            fields: "fontFamily,fontSize,foregroundColor",
          },
        });
      }
    } else {
      // STANDARD SLIDES LAYOUT
      // Title
      requests.push({
        createShape: {
          objectId: titleBoxId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: slideId,
            size: {
              width: { magnitude: 10000000, unit: "EMU" },
              height: { magnitude: 800000, unit: "EMU" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 600000,
              translateY: 400000,
              unit: "EMU",
            },
          },
        },
      });

      requests.push({
        insertText: {
          objectId: titleBoxId,
          text: slide.title,
        },
      });

      requests.push({
        updateTextStyle: {
          objectId: titleBoxId,
          style: {
            fontFamily: "Georgia",
            fontSize: { magnitude: 30, unit: "PT" },
            bold: true,
            foregroundColor: {
              opaqueColor: {
                rgbColor: { red: 61 / 255, green: 220 / 255, blue: 151 / 255 },
              },
            },
          },
          fields: "fontFamily,fontSize,bold,foregroundColor",
        },
      });

      // Subtitle
      requests.push({
        createShape: {
          objectId: subBoxId,
          shapeType: "TEXT_BOX",
          elementProperties: {
            pageObjectId: slideId,
            size: {
              width: { magnitude: 10000000, unit: "EMU" },
              height: { magnitude: 600000, unit: "EMU" },
            },
            transform: {
              scaleX: 1,
              scaleY: 1,
              translateX: 600000,
              translateY: 1200000,
              unit: "EMU",
            },
          },
        },
      });

      requests.push({
        insertText: {
          objectId: subBoxId,
          text: slide.subtitle,
        },
      });

      requests.push({
        updateTextStyle: {
          objectId: subBoxId,
          style: {
            fontFamily: "Arial",
            fontSize: { magnitude: 16, unit: "PT" },
            italic: true,
            foregroundColor: {
              opaqueColor: {
                rgbColor: { red: 140 / 255, green: 160 / 255, blue: 175 / 255 },
              },
            },
          },
          fields: "fontFamily,fontSize,italic,foregroundColor",
        },
      });

      // Bullet points
      if (slide.content && slide.content.length > 0) {
        requests.push({
          createShape: {
            objectId: contentBoxId,
            shapeType: "TEXT_BOX",
            elementProperties: {
              pageObjectId: slideId,
              size: {
                width: { magnitude: 6500000, unit: "EMU" },
                height: { magnitude: 3200000, unit: "EMU" },
              },
              transform: {
                scaleX: 1,
                scaleY: 1,
                translateX: 600000,
                translateY: 1900000,
                unit: "EMU",
              },
            },
          },
        });

        const bulletText = slide.content.map((pt) => `• ${pt}`).join("\n\n");
        requests.push({
          insertText: {
            objectId: contentBoxId,
            text: bulletText,
          },
        });

        requests.push({
          updateTextStyle: {
            objectId: contentBoxId,
            style: {
              fontFamily: "Arial",
              fontSize: { magnitude: 17, unit: "PT" },
              foregroundColor: {
                opaqueColor: {
                  rgbColor: { red: 231 / 255, green: 237 / 255, blue: 242 / 255 },
                },
              },
            },
            fields: "fontFamily,fontSize,foregroundColor",
          },
        });
      }

      // Visual suggestion box
      if (slide.visual) {
        requests.push({
          createShape: {
            objectId: visualBoxId,
            shapeType: "ROUNDED_RECTANGLE",
            elementProperties: {
              pageObjectId: slideId,
              size: {
                width: { magnitude: 4200000, unit: "EMU" },
                height: { magnitude: 1600000, unit: "EMU" },
              },
              transform: {
                scaleX: 1,
                scaleY: 1,
                translateX: 6800000,
                translateY: 3400000,
                unit: "EMU",
              },
            },
          },
        });

        requests.push({
          insertText: {
            objectId: visualBoxId,
            text: `[VISUAL SUGGESTION]: ${slide.visual}`,
          },
        });

        requests.push({
          updateShapeProperties: {
            objectId: visualBoxId,
            shapeProperties: {
              shapeBackgroundFill: {
                solidFill: {
                  color: {
                    rgbColor: { red: 30 / 255, green: 40 / 255, blue: 50 / 255 },
                  },
                },
              },
              outline: {
                outlineFill: {
                  solidFill: {
                    color: {
                      rgbColor: { red: 61 / 255, green: 220 / 255, blue: 151 / 255 },
                    },
                  },
                },
                weight: { magnitude: 12700, unit: "EMU" },
              },
            },
            fields: "shapeBackgroundFill.solidFill.color,outline",
          },
        });

        requests.push({
          updateTextStyle: {
            objectId: visualBoxId,
            style: {
              fontFamily: "Arial",
              fontSize: { magnitude: 11, unit: "PT" },
              italic: true,
              foregroundColor: {
                opaqueColor: {
                  rgbColor: { red: 140 / 255, green: 160 / 255, blue: 175 / 255 },
                },
              },
            },
            fields: "fontFamily,fontSize,italic,foregroundColor",
          },
        });
      }
    }
  });

  // Execute batch update
  const batchRes = await fetch(
    `https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ requests }),
    }
  );

  if (!batchRes.ok) {
    const errData = await batchRes.json().catch(() => ({}));
    console.warn("Batch update warning:", errData);
  }

  const presentationUrl = `https://docs.google.com/presentation/d/${presentationId}/edit`;

  return {
    presentationId,
    presentationUrl,
  };
}
