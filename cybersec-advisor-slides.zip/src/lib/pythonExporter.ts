import { DeckData } from "../types";

export function generatePythonCode(deck: DeckData): string {
  const slidesDataStr = JSON.stringify(
    deck.slides.map((s) => ({
      title: s.title,
      subtitle: s.subtitle,
      content: s.content,
      visual: s.visual,
      script: s.script,
    })),
    null,
    4
  );

  return `from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

# --- DESIGN SPECIFICATIONS ---
COLOR_BG = RGBColor(11, 15, 20)      # #0B0F14 (Near-black navy)
COLOR_ACCENT = RGBColor(61, 220, 151) # #3DDC97 (Mint/Teal)
COLOR_BODY = RGBColor(231, 237, 242) # #E7EDF2 (Light Gray)
COLOR_SUBTITLE = RGBColor(140, 160, 175) # #8CA0AF (Muted Gray)
FONT_TITLE = "Georgia"
FONT_BODY = "Arial"

# --- CONTENT DATA ---
slides_data = ${slidesDataStr}

def create_presentation():
    prs = Presentation()
    
    # Set slide dimensions (16:9)
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    for i, data in enumerate(slides_data):
        # Use blank layout for full design control
        slide_layout = prs.slide_layouts[6] 
        slide = prs.slides.add_slide(slide_layout)
        
        # 1. SET BACKGROUND
        background = slide.background
        fill = background.fill
        fill.solid()
        fill.fore_color.rgb = COLOR_BG

        # SPECIAL CASE: Title Slide (Center aligned)
        if i == 0:
            # Title
            title_box = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(11.33), Inches(1.5))
            tf = title_box.text_frame
            p = tf.paragraphs[0]
            p.text = data["title"]
            p.alignment = PP_ALIGN.CENTER
            p.font.name = FONT_TITLE
            p.font.size = Pt(60)
            p.font.bold = True
            p.font.color.rgb = COLOR_ACCENT
            
            # Subtitle
            sub_box = slide.shapes.add_textbox(Inches(1), Inches(3.8), Inches(11.33), Inches(1))
            tf = sub_box.text_frame
            p = tf.paragraphs[0]
            p.text = data["subtitle"]
            p.alignment = PP_ALIGN.CENTER
            p.font.name = FONT_BODY
            p.font.size = Pt(28)
            p.font.italic = True
            p.font.color.rgb = COLOR_SUBTITLE
            
            # Content (Team/Date)
            con_box = slide.shapes.add_textbox(Inches(1), Inches(5.0), Inches(11.33), Inches(1))
            tf = con_box.text_frame
            for line in data["content"]:
                p = tf.add_paragraph()
                p.text = line
                p.alignment = PP_ALIGN.CENTER
                p.font.name = FONT_BODY
                p.font.size = Pt(20)
                p.font.color.rgb = COLOR_BODY

        # STANDARD SLIDES
        else:
            # Title (Top-Left)
            title_box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(10), Inches(1))
            tf = title_box.text_frame
            p = tf.paragraphs[0]
            p.text = data["title"]
            p.font.name = FONT_TITLE
            p.font.size = Pt(44)
            p.font.bold = True
            p.font.color.rgb = COLOR_ACCENT
            
            # Subtitle/Main Message
            sub_box = slide.shapes.add_textbox(Inches(0.5), Inches(1.3), Inches(10), Inches(0.8))
            tf = sub_box.text_frame
            p = tf.paragraphs[0]
            p.text = data["subtitle"]
            p.font.name = FONT_BODY
            p.font.size = Pt(20)
            p.font.italic = True
            p.font.color.rgb = COLOR_SUBTITLE
            
            # Content Bullets
            content_box = slide.shapes.add_textbox(Inches(0.7), Inches(2.2), Inches(8), Inches(4))
            tf = content_box.text_frame
            tf.word_wrap = True
            
            for j, point in enumerate(data["content"]):
                if j == 0:
                    p = tf.paragraphs[0]
                else:
                    p = tf.add_paragraph()
                
                p.text = f"• {point}"
                p.font.name = FONT_BODY
                p.font.size = Pt(24)
                p.font.color.rgb = COLOR_BODY
                p.space_after = Pt(15)

        # 2. ADD VISUAL SUGGESTION PLACEHOLDER (Rounded Rect at bottom)
        if data.get("visual"):
            visual_shape = slide.shapes.add_shape(
                MSO_SHAPE.ROUNDED_RECTANGLE, 
                Inches(7), Inches(5.5), Inches(5.5), Inches(1.5)
            )
            visual_shape.fill.solid()
            visual_shape.fill.fore_color.rgb = RGBColor(30, 40, 50) # Slightly lighter navy
            visual_shape.line.color.rgb = COLOR_ACCENT
            
            v_tf = visual_shape.text_frame
            v_tf.word_wrap = True
            p = v_tf.paragraphs[0]
            p.text = f"[VISUAL SUGGESTION]: {data['visual']}"
            p.font.name = FONT_BODY
            p.font.size = Pt(14)
            p.font.italic = True
            p.font.color.rgb = COLOR_SUBTITLE
            p.alignment = PP_ALIGN.CENTER

        # 3. ADD SPEAKER NOTES
        if data.get("script"):
            notes_slide = slide.notes_slide
            notes_slide.notes_text_frame.text = data["script"]

    # Save presentation
    file_name = "${deck.title.replace(/[^a-zA-Z0-9_-]/g, "_")}_Presentation.pptx"
    prs.save(file_name)
    return file_name

if __name__ == "__main__":
    output_file = create_presentation()
    print(f"Successfully generated {output_file}")
`;
}
