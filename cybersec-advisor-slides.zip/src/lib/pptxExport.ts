import pptxgen from "pptxgenjs";
import { DeckData } from "../types";

export function exportToPPTX(deck: DeckData): void {
  const pptx = new pptxgen();

  pptx.layout = "LAYOUT_16x9";
  pptx.title = deck.title;

  const COLOR_BG = "0B0F14";
  const COLOR_ACCENT = "3DDC97";
  const COLOR_BODY = "E7EDF2";
  const COLOR_SUBTITLE = "8CA0AF";
  const COLOR_VISUAL_BG = "1E2832";

  deck.slides.forEach((slideData, i) => {
    const slide = pptx.addSlide();

    // Background color
    slide.background = { color: COLOR_BG };

    if (i === 0) {
      // TITLE SLIDE
      slide.addText(slideData.title, {
        x: 1.0,
        y: 2.5,
        w: 11.33,
        h: 1.5,
        align: "center",
        fontFace: "Georgia",
        fontSize: 54,
        bold: true,
        color: COLOR_ACCENT,
      });

      slide.addText(slideData.subtitle, {
        x: 1.0,
        y: 3.8,
        w: 11.33,
        h: 1.0,
        align: "center",
        fontFace: "Arial",
        fontSize: 24,
        italic: true,
        color: COLOR_SUBTITLE,
      });

      if (slideData.content && slideData.content.length > 0) {
        slide.addText(slideData.content.join("\n"), {
          x: 1.0,
          y: 5.0,
          w: 11.33,
          h: 1.2,
          align: "center",
          fontFace: "Arial",
          fontSize: 18,
          color: COLOR_BODY,
        });
      }
    } else {
      // STANDARD SLIDE
      slide.addText(slideData.title, {
        x: 0.5,
        y: 0.5,
        w: 10.0,
        h: 0.8,
        fontFace: "Georgia",
        fontSize: 36,
        bold: true,
        color: COLOR_ACCENT,
      });

      slide.addText(slideData.subtitle, {
        x: 0.5,
        y: 1.3,
        w: 10.0,
        h: 0.8,
        fontFace: "Arial",
        fontSize: 18,
        italic: true,
        color: COLOR_SUBTITLE,
      });

      // Bullets
      if (slideData.content && slideData.content.length > 0) {
        const bulletObjects = slideData.content.map((pt) => ({
          text: pt,
          options: {
            bullet: true,
            fontFace: "Arial",
            fontSize: 20,
            color: COLOR_BODY,
            spaceAfter: 12,
          },
        }));

        slide.addText(bulletObjects, {
          x: 0.7,
          y: 2.2,
          w: 7.5,
          h: 4.5,
        });
      }

      // Visual box suggestion
      if (slideData.visual) {
        slide.addShape(pptx.ShapeType.roundRect, {
          x: 7.0,
          y: 5.2,
          w: 5.5,
          h: 1.8,
          fill: { color: COLOR_VISUAL_BG },
          line: { color: COLOR_ACCENT, width: 1.5 },
        });

        slide.addText(`[VISUAL SUGGESTION]: ${slideData.visual}`, {
          x: 7.1,
          y: 5.3,
          w: 5.3,
          h: 1.6,
          fontFace: "Arial",
          fontSize: 12,
          italic: true,
          color: COLOR_SUBTITLE,
          align: "center",
        });
      }
    }

    // Speaker notes
    if (slideData.script) {
      slide.addNotes(slideData.script);
    }
  });

  const filename = `${deck.title.replace(/[^a-zA-Z0-9_-]/g, "_")}_Presentation.pptx`;
  pptx.writeFile({ fileName: filename });
}
