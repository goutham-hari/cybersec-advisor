import React from "react";
import { Slide } from "../types";
import {
  Shield,
  FileText,
  Search,
  Database,
  Cpu,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  BarChart3,
  ListOrdered,
  ArrowRight,
  Layers,
  Sparkles,
  Zap,
} from "lucide-react";

interface SlideCanvasProps {
  slide: Slide;
  slideNumber: number;
  totalSlides: number;
}

export const SlideCanvas: React.FC<SlideCanvasProps> = ({
  slide,
  slideNumber,
  totalSlides,
}) => {
  const isTitleSlide = slide.layoutType === "title" || slideNumber === 1;

  return (
    <div className="w-full h-full bg-[#0B0F14] text-[#E7EDF2] flex flex-col justify-between p-6 sm:p-10 relative overflow-hidden select-none font-sans border border-[#3DDC97]/20 shadow-2xl rounded-3xl">
      {/* Background Subtle Tech Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#3ddc9708_1px,transparent_1px),linear-gradient(to_bottom,#3ddc9708_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none" />
      <div className="absolute top-0 right-0 w-80 h-80 bg-[#3DDC97]/5 blur-[100px] rounded-full pointer-events-none" />

      {/* Slide Header */}
      {!isTitleSlide && (
        <div className="z-10 mb-3 flex justify-between items-start">
          <div>
            <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#3DDC97] tracking-tight leading-none">
              {slide.title}
            </h2>
            {slide.subtitle && (
              <p className="text-sm sm:text-base italic text-[#8CA0AF] mt-1 font-sans">
                {slide.subtitle}
              </p>
            )}
          </div>
          <div className="hidden sm:flex items-center space-x-2 bg-[#161B22] border border-[#3DDC97]/30 px-3 py-1 rounded-full">
            <div className="w-1.5 h-1.5 rounded-full bg-[#3DDC97] animate-pulse" />
            <span className="text-[10px] font-mono text-[#3DDC97] uppercase tracking-widest">
              Secured Source
            </span>
          </div>
        </div>
      )}

      {/* Main Slide Body */}
      <div className="z-10 flex-1 flex flex-col justify-center my-2">
        {isTitleSlide ? (
          /* TITLE SLIDE BENTO LAYOUT */
          <div className="bg-[#161B22] rounded-3xl p-6 sm:p-8 border border-[#3DDC97]/20 text-center flex flex-col items-center justify-center space-y-5 my-auto relative overflow-hidden">
            <div className="w-16 h-16 rounded-2xl bg-[#3DDC97]/20 border border-[#3DDC97]/40 flex items-center justify-center text-[#3DDC97] shadow-xl shadow-[#3DDC97]/10 mb-1">
              <Shield className="w-9 h-9" />
            </div>
            <h1 className="text-3xl sm:text-5xl font-bold font-serif text-[#3DDC97] leading-tight max-w-3xl tracking-tight">
              {slide.title}
            </h1>
            <p className="text-base sm:text-xl italic text-[#8CA0AF] max-w-2xl font-light">
              {slide.subtitle}
            </p>

            <div className="w-full max-w-xl pt-4 border-t border-[#3DDC97]/10 text-xs sm:text-sm space-y-1.5">
              {slide.content?.map((line, idx) => (
                <div key={idx} className="flex items-center justify-center gap-2 text-[#E7EDF2] font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3DDC97]" />
                  <span>{line}</span>
                </div>
              ))}
            </div>
          </div>
        ) : slide.layoutType === "architecture" ? (
          /* ARCHITECTURE / RAG FLOW BENTO LAYOUT */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            {/* Left Bullet Points Bento Box */}
            <div className="lg:col-span-6 bg-[#161B22] rounded-3xl p-5 border border-[#3DDC97]/10 space-y-3">
              {slide.content?.map((point, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#3DDC97] mt-2 shrink-0" />
                  <p className="text-xs sm:text-sm text-[#E7EDF2] leading-relaxed">
                    {point}
                  </p>
                </div>
              ))}
            </div>

            {/* Right Flow Diagram Bento Graphic */}
            <div className="lg:col-span-6 bg-[#161B22] border border-[#3DDC97]/20 rounded-3xl p-5 shadow-xl">
              <h3 className="text-xs font-semibold mb-4 uppercase tracking-widest text-[#3DDC97] font-mono flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#3DDC97]" />
                System Pipeline Architecture
              </h3>
              <div className="space-y-2.5">
                <div className="flex items-center gap-3 bg-[#0B0F14] p-3 rounded-2xl border border-[#3DDC97]/20">
                  <BookOpen className="w-5 h-5 text-[#3DDC97] shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-[#E7EDF2]">PDF Knowledge Library</p>
                    <p className="text-[10px] text-[#8CA0AF]">Automatic PDF Chunking & Indexing</p>
                  </div>
                </div>
                <div className="text-center text-[#3DDC97] text-xs font-mono">↓</div>
                <div className="flex items-center gap-3 bg-[#0B0F14] p-3 rounded-2xl border border-[#3DDC97]">
                  <Search className="w-5 h-5 text-[#3DDC97] shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-[#E7EDF2]">Hybrid Vector Engine</p>
                    <p className="text-[10px] text-[#8CA0AF]">Semantic Embeddings + BM25 Lexical</p>
                  </div>
                </div>
                <div className="text-center text-[#3DDC97] text-xs font-mono">↓</div>
                <div className="flex items-center gap-3 bg-[#3DDC97]/10 p-3 rounded-2xl border border-[#3DDC97]/40">
                  <Cpu className="w-5 h-5 text-[#3DDC97] shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-[#3DDC97]">Grounded LLM Answer</p>
                    <p className="text-[10px] text-[#E7EDF2]">Deterministic Book/Page Citations</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : slide.layoutType === "features" ? (
          /* BENTO QUADRANT FEATURE GRID LAYOUT */
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-[#161B22] border border-[#3DDC97]/10 p-4 rounded-2xl flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#3DDC97]/20 text-[#3DDC97] flex items-center justify-center shrink-0">
                  <Search className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#E7EDF2]">Hybrid Retrieval</h4>
                  <p className="text-[11px] text-[#8CA0AF] mt-0.5">Vector + BM25 Reciprocal Rank Fusion</p>
                </div>
              </div>

              <div className="bg-[#161B22] border border-[#3DDC97]/10 p-4 rounded-2xl flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#3DDC97]/20 text-[#3DDC97] flex items-center justify-center shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#E7EDF2]">Deterministic Citations</h4>
                  <p className="text-[11px] text-[#8CA0AF] mt-0.5">Direct book and page number references</p>
                </div>
              </div>

              <div className="bg-[#161B22] border border-[#3DDC97]/10 p-4 rounded-2xl flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#3DDC97]/20 text-[#3DDC97] flex items-center justify-center shrink-0">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#E7EDF2]">Private Local Storage</h4>
                  <p className="text-[11px] text-[#8CA0AF] mt-0.5">Offline vector store with zero cloud cost</p>
                </div>
              </div>

              <div className="bg-[#161B22] border border-[#3DDC97]/10 p-4 rounded-2xl flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#3DDC97]/20 text-[#3DDC97] flex items-center justify-center shrink-0">
                  <Shield className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-[#E7EDF2]">Security Guardrails</h4>
                  <p className="text-[11px] text-[#8CA0AF] mt-0.5">Responsible-use scope system prompt</p>
                </div>
              </div>
            </div>

            <div className="bg-[#161B22] border border-[#3DDC97]/10 p-3 rounded-2xl flex items-center justify-around text-xs font-mono text-[#8CA0AF]">
              {slide.content?.map((point, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3DDC97]" />
                  <span className="text-[#E7EDF2] text-xs">{point}</span>
                </div>
              ))}
            </div>
          </div>
        ) : slide.layoutType === "results" ? (
          /* BENTO METRIC & RESULTS LAYOUT */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            {/* Left Content Card */}
            <div className="lg:col-span-5 bg-[#161B22] rounded-3xl p-5 border border-[#3DDC97]/10 space-y-3">
              {slide.content?.map((point, idx) => (
                <div key={idx} className="flex items-start gap-2.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3DDC97] mt-2 shrink-0" />
                  <p className="text-xs sm:text-sm text-[#E7EDF2] leading-snug">
                    {point}
                  </p>
                </div>
              ))}
            </div>

            {/* Right Metric Bento Grid Cards */}
            <div className="lg:col-span-7 grid grid-cols-2 gap-3">
              <div className="bg-[#161B22] rounded-3xl p-4 border border-[#3DDC97]/20 flex flex-col items-center justify-center text-center">
                <span className="text-[#8CA0AF] text-[10px] uppercase tracking-widest font-mono mb-1">Hit Rate @ 10</span>
                <span className="text-4xl font-bold text-[#3DDC97] font-mono">94.2<span class="text-xl">%</span></span>
                <div className="w-full bg-[#0B0F14] h-1.5 rounded-full mt-3 overflow-hidden">
                  <div className="bg-[#3DDC97] h-full w-[94.2%]" />
                </div>
              </div>

              <div className="bg-[#161B22] rounded-3xl p-4 border border-[#3DDC97]/20 flex flex-col items-center justify-center text-center">
                <span className="text-[#8CA0AF] text-[10px] uppercase tracking-widest font-mono mb-1">Hybrid Precision</span>
                <span className="text-4xl font-bold text-[#E7EDF2] font-mono">+22<span class="text-xl">%</span></span>
                <p className="text-[#8CA0AF] text-[9px] mt-1 italic">Over vector-only search</p>
              </div>

              <div className="col-span-2 bg-[#161B22] rounded-2xl p-3.5 border border-[#3DDC97]/10 flex items-center justify-between">
                <span className="text-[11px] font-mono text-[#8CA0AF]">Retrieval Accuracy</span>
                <span className="text-xs font-mono text-[#3DDC97] font-bold">✔ Verified CVE Recall</span>
              </div>
            </div>
          </div>
        ) : slide.layoutType === "roadmap" ? (
          /* BENTO ROADMAP & MILESTONES LAYOUT */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[#161B22] border border-[#3DDC97]/10 rounded-3xl p-5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#8CA0AF] block mb-2">Milestone Solved</span>
              <h3 className="text-sm font-bold text-[#E7EDF2] flex items-center gap-2 mb-3">
                <CheckCircle2 className="w-4 h-4 text-[#3DDC97]" />
                Engineering Achievements
              </h3>
              <ul className="space-y-2.5 text-xs text-[#E7EDF2]">
                {slide.content?.slice(0, 2).map((pt, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-[#3DDC97] font-bold">✓</span>
                    <span>{pt}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-[#3DDC97] text-[#0B0F14] rounded-3xl p-5 flex flex-col justify-between shadow-xl">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest font-bold opacity-80">Next Milestone</span>
                <h3 className="text-lg font-serif font-bold leading-tight mt-1">
                  Cross-Encoder Reranking Engine
                </h3>
                <p className="text-xs mt-2 italic opacity-90 leading-relaxed">
                  Enhancing Precision @ 1 with two-stage neural reranking for exact passage extraction.
                </p>
              </div>
              <div className="flex items-center justify-between text-xs font-mono font-bold pt-3 border-t border-[#0B0F14]/20 mt-3">
                <span>Phase 2.0 Roadmap</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ) : slide.layoutType === "agenda" ? (
          /* BENTO AGENDA LIST LAYOUT */
          <div className="space-y-2.5 my-auto max-w-2xl mx-auto w-full">
            {slide.content?.map((point, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between bg-[#161B22] border border-[#3DDC97]/10 px-4 py-3 rounded-2xl hover:border-[#3DDC97]/40 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-7 h-7 rounded-xl bg-[#3DDC97]/20 text-[#3DDC97] font-mono text-xs font-bold flex items-center justify-center shrink-0">
                    0{idx + 1}
                  </div>
                  <p className="text-xs sm:text-sm text-[#E7EDF2] font-medium">{point}</p>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-[#3DDC97]" />
              </div>
            ))}
          </div>
        ) : (
          /* STANDARD BENTO BULLET + VISUAL CARD LAYOUT */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
            <div className="lg:col-span-7 bg-[#161B22] rounded-3xl p-5 border border-[#3DDC97]/10 space-y-3">
              {slide.content?.map((point, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-[#3DDC97] mt-2 shrink-0" />
                  <p className="text-xs sm:text-sm text-[#E7EDF2] leading-relaxed">
                    {point}
                  </p>
                </div>
              ))}
            </div>

            {/* Visual Suggestion Bento Card */}
            {slide.visual && (
              <div className="lg:col-span-5 bg-[#161B22] border border-[#3DDC97]/20 rounded-3xl p-5 text-center flex flex-col justify-center items-center shadow-lg min-h-[160px] relative">
                <Sparkles className="w-5 h-5 text-[#3DDC97] mb-2" />
                <span className="text-[10px] font-mono uppercase tracking-widest text-[#3DDC97] mb-1">Visual Diagram Concept</span>
                <p className="text-xs text-[#8CA0AF] italic font-sans leading-relaxed">
                  {slide.visual}
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Slide Footer */}
      <div className="z-10 pt-3 border-t border-[#3DDC97]/10 flex items-center justify-between text-[11px] text-[#8CA0AF] font-mono">
        <div className="flex items-center gap-2">
          <Shield className="w-3.5 h-3.5 text-[#3DDC97]" />
          <span>CyberSec Advisor // Zero-Trust RAG Architecture</span>
        </div>
        <div className="tracking-widest uppercase text-[#3DDC97]">
          Slide {slideNumber} of {totalSlides}
        </div>
      </div>
    </div>
  );
};
