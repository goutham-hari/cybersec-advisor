import React from "react";
import { Slide } from "../types";
import {
  Plus,
  Copy,
  Trash2,
  ChevronUp,
  ChevronDown,
  Layers,
} from "lucide-react";

interface SlideListProps {
  slides: Slide[];
  activeSlideIndex: number;
  onSelectSlide: (index: number) => void;
  onAddSlide: () => void;
  onDuplicateSlide: (index: number) => void;
  onDeleteSlide: (index: number) => void;
  onMoveSlide: (index: number, direction: "up" | "down") => void;
}

export const SlideList: React.FC<SlideListProps> = ({
  slides,
  activeSlideIndex,
  onSelectSlide,
  onAddSlide,
  onDuplicateSlide,
  onDeleteSlide,
  onMoveSlide,
}) => {
  return (
    <div className="w-full h-full bg-[#161B22] border-r border-[#3DDC97]/10 flex flex-col">
      {/* Sidebar Header */}
      <div className="p-3.5 border-b border-[#3DDC97]/10 flex items-center justify-between bg-[#0B0F14]">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#E7EDF2] font-mono tracking-wider">
          <Layers className="w-4 h-4 text-[#3DDC97]" />
          <span>SLIDES ({slides.length})</span>
        </div>
        <button
          onClick={onAddSlide}
          className="flex items-center gap-1 text-xs bg-[#3DDC97]/20 hover:bg-[#3DDC97]/30 text-[#3DDC97] border border-[#3DDC97]/40 px-2.5 py-1 rounded-xl transition-all font-mono font-medium"
          title="Add new slide"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New</span>
        </button>
      </div>

      {/* Thumbnails Scroll Container */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {slides.map((slide, index) => {
          const isActive = index === activeSlideIndex;
          return (
            <div
              key={slide.id || index}
              onClick={() => onSelectSlide(index)}
              className={`group relative rounded-2xl p-3 cursor-pointer border transition-all ${
                isActive
                  ? "bg-[#0B0F14] border-[#3DDC97] shadow-lg shadow-[#3DDC97]/10"
                  : "bg-[#0B0F14]/60 border-[#3DDC97]/10 hover:border-[#3DDC97]/30 hover:bg-[#0B0F14]"
              }`}
            >
              {/* Number Badge */}
              <div className="flex items-center justify-between mb-2">
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                    isActive
                      ? "bg-[#3DDC97] text-[#0B0F14]"
                      : "bg-[#161B22] text-[#8CA0AF] border border-[#3DDC97]/10"
                  }`}
                >
                  0{index + 1}
                </span>

                {/* Quick Action Overlay */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-[#161B22]/95 backdrop-blur rounded-xl px-1.5 py-0.5 border border-[#3DDC97]/20">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveSlide(index, "up");
                    }}
                    disabled={index === 0}
                    className="p-1 hover:text-[#3DDC97] disabled:opacity-30 text-[#8CA0AF]"
                    title="Move Up"
                  >
                    <ChevronUp className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onMoveSlide(index, "down");
                    }}
                    disabled={index === slides.length - 1}
                    className="p-1 hover:text-[#3DDC97] disabled:opacity-30 text-[#8CA0AF]"
                    title="Move Down"
                  >
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDuplicateSlide(index);
                    }}
                    className="p-1 hover:text-[#3DDC97] text-[#8CA0AF]"
                    title="Duplicate"
                  >
                    <Copy className="w-3 h-3" />
                  </button>
                  {slides.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSlide(index);
                      }}
                      className="p-1 hover:text-rose-400 text-[#8CA0AF]"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              {/* Mini Preview Box */}
              <div className="bg-[#161B22] p-2.5 rounded-xl border border-[#3DDC97]/10 min-h-[56px] flex flex-col justify-between">
                <p className="text-xs font-serif font-semibold text-[#E7EDF2] line-clamp-1">
                  {slide.title || "Untitled Slide"}
                </p>
                <p className="text-[10px] text-[#8CA0AF] line-clamp-1 italic mt-0.5 font-sans">
                  {slide.subtitle || slide.content?.[0] || "No description"}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
