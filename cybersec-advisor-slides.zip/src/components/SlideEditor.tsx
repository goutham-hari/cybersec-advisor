import React, { useState } from "react";
import { Slide, LayoutType } from "../types";
import {
  Type,
  List,
  Sparkles,
  FileText,
  Image,
  Plus,
  Trash2,
  Loader2,
  Layout,
} from "lucide-react";

interface SlideEditorProps {
  slide: Slide;
  onUpdateSlide: (updatedSlide: Slide) => void;
}

export const SlideEditor: React.FC<SlideEditorProps> = ({
  slide,
  onUpdateSlide,
}) => {
  const [activeTab, setActiveTab] = useState<
    "content" | "notes" | "visual" | "ai"
  >("content");

  const [aiAction, setAiAction] = useState<string | null>(null);
  const [customAiPrompt, setCustomAiPrompt] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const handleTitleChange = (title: string) => {
    onUpdateSlide({ ...slide, title });
  };

  const handleSubtitleChange = (subtitle: string) => {
    onUpdateSlide({ ...slide, subtitle });
  };

  const handleLayoutTypeChange = (layoutType: LayoutType) => {
    onUpdateSlide({ ...slide, layoutType });
  };

  const handleBulletChange = (index: number, text: string) => {
    const newContent = [...slide.content];
    newContent[index] = text;
    onUpdateSlide({ ...slide, content: newContent });
  };

  const handleAddBullet = () => {
    onUpdateSlide({ ...slide, content: [...slide.content, "New bullet point"] });
  };

  const handleRemoveBullet = (index: number) => {
    const newContent = slide.content.filter((_, i) => i !== index);
    onUpdateSlide({ ...slide, content: newContent });
  };

  const handleScriptChange = (script: string) => {
    onUpdateSlide({ ...slide, script });
  };

  const handleVisualChange = (visual: string) => {
    onUpdateSlide({ ...slide, visual });
  };

  // Run AI Refinement via backend /api/ai/refine
  const runAiRefine = async (action: string) => {
    setIsAiLoading(true);
    setAiError(null);
    setAiAction(action);

    try {
      const res = await fetch("/api/ai/refine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action,
          slide,
          customPrompt: customAiPrompt,
        }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "AI refinement request failed.");
      }

      const data = await res.json();
      if (action === "refine_bullets") {
        try {
          const parsedBullets = JSON.parse(data.result);
          if (Array.isArray(parsedBullets)) {
            onUpdateSlide({ ...slide, content: parsedBullets });
          } else {
            onUpdateSlide({
              ...slide,
              content: data.result.split("\n").filter(Boolean),
            });
          }
        } catch {
          onUpdateSlide({
            ...slide,
            content: data.result.split("\n").filter(Boolean),
          });
        }
      } else if (action === "generate_script") {
        onUpdateSlide({ ...slide, script: data.result });
      } else if (action === "suggest_visual") {
        onUpdateSlide({ ...slide, visual: data.result });
      } else if (action === "custom") {
        onUpdateSlide({ ...slide, script: data.result });
      }
    } catch (err: any) {
      console.error("AI refine error:", err);
      setAiError(err.message || "Failed to process AI refinement.");
    } finally {
      setIsAiLoading(false);
      setAiAction(null);
    }
  };

  return (
    <div className="w-full h-full bg-[#161B22] border-t lg:border-t-0 lg:border-l border-[#3DDC97]/10 flex flex-col text-[#E7EDF2]">
      {/* Editor Tabs Header */}
      <div className="flex items-center border-b border-[#3DDC97]/10 bg-[#0B0F14] px-2 pt-2">
        <button
          onClick={() => setActiveTab("content")}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-all ${
            activeTab === "content"
              ? "border-[#3DDC97] text-[#3DDC97] bg-[#161B22]"
              : "border-transparent text-[#8CA0AF] hover:text-[#E7EDF2]"
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>Content</span>
        </button>

        <button
          onClick={() => setActiveTab("notes")}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-all ${
            activeTab === "notes"
              ? "border-[#3DDC97] text-[#3DDC97] bg-[#161B22]"
              : "border-transparent text-[#8CA0AF] hover:text-[#E7EDF2]"
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Speaker Notes</span>
        </button>

        <button
          onClick={() => setActiveTab("visual")}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-all ${
            activeTab === "visual"
              ? "border-[#3DDC97] text-[#3DDC97] bg-[#161B22]"
              : "border-transparent text-[#8CA0AF] hover:text-[#E7EDF2]"
          }`}
        >
          <Image className="w-3.5 h-3.5" />
          <span>Visual Layout</span>
        </button>

        <button
          onClick={() => setActiveTab("ai")}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium border-b-2 transition-all ${
            activeTab === "ai"
              ? "border-[#3DDC97] text-[#3DDC97] bg-[#161B22]"
              : "border-transparent text-[#3DDC97]/80 hover:text-[#3DDC97]"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>AI Refine</span>
        </button>
      </div>

      {/* Editor Content Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {activeTab === "content" && (
          <div className="space-y-4">
            {/* Slide Title */}
            <div>
              <label className="block text-[11px] font-mono text-[#8CA0AF] mb-1">
                SLIDE TITLE
              </label>
              <input
                type="text"
                value={slide.title}
                onChange={(e) => handleTitleChange(e.target.value)}
                className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-3 py-2 text-sm text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
              />
            </div>

            {/* Slide Subtitle */}
            <div>
              <label className="block text-[11px] font-mono text-[#8CA0AF] mb-1">
                SUBTITLE / MAIN TAKEAWAY
              </label>
              <input
                type="text"
                value={slide.subtitle}
                onChange={(e) => handleSubtitleChange(e.target.value)}
                className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-3 py-2 text-sm text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
              />
            </div>

            {/* Layout Type Selection */}
            <div>
              <label className="block text-[11px] font-mono text-[#8CA0AF] mb-1 flex items-center gap-1">
                <Layout className="w-3.5 h-3.5 text-[#3DDC97]" />
                VISUAL LAYOUT TEMPLATE
              </label>
              <select
                value={slide.layoutType}
                onChange={(e) =>
                  handleLayoutTypeChange(e.target.value as LayoutType)
                }
                className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-3 py-2 text-sm text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
              >
                <option value="title">Title Card</option>
                <option value="agenda">Agenda / Timeline</option>
                <option value="architecture">RAG Architecture Flow</option>
                <option value="features">4-Quadrant Feature Grid</option>
                <option value="results">Evaluation Metric Chart</option>
                <option value="roadmap">Challenges & Roadmap</option>
                <option value="conclusion">Conclusion Shield Badge</option>
                <option value="qa">Q&A Slide</option>
                <option value="standard">Standard Bullets + Visual Card</option>
              </select>
            </div>

            {/* Bullet Points List */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-mono text-[#8CA0AF]">
                  KEY BULLET POINTS ({slide.content?.length || 0})
                </label>
                <button
                  onClick={handleAddBullet}
                  className="flex items-center gap-1 text-[11px] text-[#3DDC97] hover:underline"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Point</span>
                </button>
              </div>

              <div className="space-y-2">
                {slide.content?.map((point, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="text-[#3DDC97] text-xs font-bold font-mono">
                      •
                    </span>
                    <input
                      type="text"
                      value={point}
                      onChange={(e) => handleBulletChange(idx, e.target.value)}
                      className="flex-1 bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-2.5 py-1.5 text-xs text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
                    />
                    <button
                      onClick={() => handleRemoveBullet(idx)}
                      className="p-1 text-[#8CA0AF] hover:text-rose-400"
                      title="Remove bullet"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "notes" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-mono text-[#8CA0AF]">
                SPEAKER NOTES & TELEPROMPTER SCRIPT
              </label>
              <button
                onClick={() => runAiRefine("generate_script")}
                disabled={isAiLoading}
                className="flex items-center gap-1 text-[11px] text-[#3DDC97] hover:underline disabled:opacity-50"
              >
                <Sparkles className="w-3 h-3" />
                <span>Auto-generate Script</span>
              </button>
            </div>

            <textarea
              rows={10}
              value={slide.script}
              onChange={(e) => handleScriptChange(e.target.value)}
              placeholder="Enter spoken text for presentation talk-track..."
              className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl p-3 text-xs text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97] leading-relaxed font-sans"
            />
          </div>
        )}

        {activeTab === "visual" && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-mono text-[#8CA0AF]">
                VISUAL DIAGRAM / GRAPHIC SUGGESTION
              </label>
              <button
                onClick={() => runAiRefine("suggest_visual")}
                disabled={isAiLoading}
                className="flex items-center gap-1 text-[11px] text-[#3DDC97] hover:underline disabled:opacity-50"
              >
                <Sparkles className="w-3 h-3" />
                <span>AI Suggestion</span>
              </button>
            </div>

            <textarea
              rows={6}
              value={slide.visual}
              onChange={(e) => handleVisualChange(e.target.value)}
              placeholder="Describe graphic or flowchart suggestion for this slide..."
              className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl p-3 text-xs text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97] leading-relaxed font-sans"
            />
          </div>
        )}

        {activeTab === "ai" && (
          <div className="space-y-4">
            <div className="p-3.5 bg-[#0B0F14] border border-[#3DDC97]/30 rounded-2xl text-xs text-[#3DDC97]">
              <p className="font-semibold mb-0.5">Gemini AI Assistant</p>
              <p className="text-[#8CA0AF] text-[11px]">
                Enhance slide text, generate natural presenter talk-tracks, or craft technical diagram ideas.
              </p>
            </div>

            <div className="grid grid-cols-1 gap-2">
              <button
                onClick={() => runAiRefine("refine_bullets")}
                disabled={isAiLoading}
                className="flex items-center justify-between p-3 bg-[#0B0F14] hover:bg-[#0F151C] border border-[#3DDC97]/10 hover:border-[#3DDC97]/40 rounded-2xl text-xs text-left transition-all group disabled:opacity-50"
              >
                <div>
                  <p className="font-medium text-[#E7EDF2] group-hover:text-[#3DDC97]">
                    Refine Bullet Points
                  </p>
                  <p className="text-[11px] text-[#8CA0AF]">
                    Make bullets concise, technical, and high-impact
                  </p>
                </div>
                {isAiLoading && aiAction === "refine_bullets" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-[#3DDC97]" />
                ) : (
                  <Sparkles className="w-4 h-4 text-[#8CA0AF] group-hover:text-[#3DDC97]" />
                )}
              </button>

              <button
                onClick={() => runAiRefine("generate_script")}
                disabled={isAiLoading}
                className="flex items-center justify-between p-3 bg-[#0B0F14] hover:bg-[#0F151C] border border-[#3DDC97]/10 hover:border-[#3DDC97]/40 rounded-2xl text-xs text-left transition-all group disabled:opacity-50"
              >
                <div>
                  <p className="font-medium text-[#E7EDF2] group-hover:text-[#3DDC97]">
                    Generate Speaker Script
                  </p>
                  <p className="text-[11px] text-[#8CA0AF]">
                    Write natural spoken script for presenter view
                  </p>
                </div>
                {isAiLoading && aiAction === "generate_script" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-[#3DDC97]" />
                ) : (
                  <Sparkles className="w-4 h-4 text-[#8CA0AF] group-hover:text-[#3DDC97]" />
                )}
              </button>

              <button
                onClick={() => runAiRefine("suggest_visual")}
                disabled={isAiLoading}
                className="flex items-center justify-between p-3 bg-[#0B0F14] hover:bg-[#0F151C] border border-[#3DDC97]/10 hover:border-[#3DDC97]/40 rounded-2xl text-xs text-left transition-all group disabled:opacity-50"
              >
                <div>
                  <p className="font-medium text-[#E7EDF2] group-hover:text-[#3DDC97]">
                    Suggest Visual Layout
                  </p>
                  <p className="text-[11px] text-[#8CA0AF]">
                    Recommend flowcharts or data diagrams
                  </p>
                </div>
                {isAiLoading && aiAction === "suggest_visual" ? (
                  <Loader2 className="w-4 h-4 animate-spin text-[#3DDC97]" />
                ) : (
                  <Sparkles className="w-4 h-4 text-[#8CA0AF] group-hover:text-[#3DDC97]" />
                )}
              </button>
            </div>

            {/* Custom AI Input */}
            <div className="pt-2 border-t border-[#3DDC97]/10">
              <label className="block text-[11px] font-mono text-[#8CA0AF] mb-1">
                CUSTOM INSTRUCTION TO GEMINI
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customAiPrompt}
                  onChange={(e) => setCustomAiPrompt(e.target.value)}
                  placeholder="e.g., Make it more focused on CVE search..."
                  className="flex-1 bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-2.5 py-1.5 text-xs text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
                />
                <button
                  onClick={() => runAiRefine("custom")}
                  disabled={isAiLoading || !customAiPrompt.trim()}
                  className="px-3.5 py-1.5 bg-[#3DDC97] hover:bg-[#34C787] text-[#0B0F14] font-semibold rounded-xl text-xs transition-all disabled:opacity-50"
                >
                  Run
                </button>
              </div>
            </div>

            {aiError && (
              <p className="text-xs text-rose-400 bg-rose-950/50 p-2 rounded border border-rose-800">
                {aiError}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
