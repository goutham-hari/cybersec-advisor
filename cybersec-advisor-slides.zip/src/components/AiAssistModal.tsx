import React, { useState } from "react";
import { DeckData } from "../types";
import { X, Sparkles, Loader2, RefreshCw } from "lucide-react";

interface AiAssistModalProps {
  onGenerateNewDeck: (newDeck: DeckData) => void;
  onClose: () => void;
}

export const AiAssistModal: React.FC<AiAssistModalProps> = ({
  onGenerateNewDeck,
  onClose,
}) => {
  const [topic, setTopic] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/ai/generate-deck", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to generate presentation deck.");
      }

      const generated = await res.json();
      if (!generated.slides || !Array.isArray(generated.slides)) {
        throw new Error("Invalid slide deck format returned from AI.");
      }

      const formattedDeck: DeckData = {
        title: generated.title || topic,
        subtitle: `Generated AI Research Deck on ${topic}`,
        slides: generated.slides.map((s: any, idx: number) => ({
          id: `ai-slide-${idx + 1}`,
          title: s.title || `Slide ${idx + 1}`,
          subtitle: s.subtitle || "",
          content: Array.isArray(s.content) ? s.content : [s.content || ""],
          visual: s.visual || "Diagram placeholder",
          script: s.script || "",
          layoutType: s.layoutType || "standard",
        })),
      };

      onGenerateNewDeck(formattedDeck);
      onClose();
    } catch (err: any) {
      console.error("AI deck generation failed:", err);
      setError(err.message || "Failed to generate deck.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#161B22] border border-[#3DDC97]/20 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-[#3DDC97]/10 flex items-center justify-between bg-[#0B0F14]">
          <div className="flex items-center gap-2 text-[#E7EDF2] font-semibold text-sm">
            <Sparkles className="w-4 h-4 text-[#3DDC97]" />
            <span>Generate New Presentation Deck</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8CA0AF] hover:text-[#E7EDF2] rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          <p className="text-xs text-[#8CA0AF] leading-relaxed">
            Enter any cybersecurity research topic, vulnerability analysis, or tech concept to generate a structured 6-slide research presentation complete with speaker notes and visual diagram suggestions.
          </p>

          <div>
            <label className="block text-[11px] font-mono text-[#8CA0AF] mb-1">
              RESEARCH TOPIC / SUBJECT
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Zero Trust Architecture in Cloud Environments..."
              className="w-full bg-[#0B0F14] border border-[#3DDC97]/20 rounded-xl px-3 py-2 text-sm text-[#E7EDF2] focus:outline-none focus:border-[#3DDC97]"
            />
          </div>

          {error && (
            <p className="text-xs text-rose-400 bg-rose-950/50 p-2.5 rounded-xl border border-rose-800">
              {error}
            </p>
          )}

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#0B0F14] hover:bg-[#0F151C] text-[#8CA0AF] rounded-xl text-xs font-medium border border-[#3DDC97]/10"
            >
              Cancel
            </button>
            <button
              onClick={handleGenerate}
              disabled={isLoading || !topic.trim()}
              className="px-4 py-2 bg-[#3DDC97] hover:bg-[#34C787] disabled:opacity-50 text-[#0B0F14] font-semibold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md shadow-[#3DDC97]/10"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generating Deck...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  <span>Generate Deck</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
