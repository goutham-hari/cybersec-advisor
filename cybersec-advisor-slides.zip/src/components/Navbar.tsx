import React, { useState } from "react";
import {
  Shield,
  Presentation,
  Download,
  Code2,
  Play,
  Sparkles,
  LogOut,
  ExternalLink,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { UserProfile, DeckData } from "../types";
import { googleSignIn, logout } from "../lib/firebase";
import { createGoogleSlidesPresentation } from "../lib/googleSlides";
import { exportToPPTX } from "../lib/pptxExport";

interface NavbarProps {
  user: UserProfile | null;
  accessToken: string | null;
  deck: DeckData;
  onOpenPythonModal: () => void;
  onOpenPresenterModal: () => void;
  onOpenAiAssistModal: () => void;
  onAuthSuccess: (user: any, token: string) => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  accessToken,
  deck,
  onOpenPythonModal,
  onOpenPresenterModal,
  onOpenAiAssistModal,
  onAuthSuccess,
  onLogout,
}) => {
  const [isExportingSlides, setIsExportingSlides] = useState(false);
  const [exportSuccessUrl, setExportSuccessUrl] = useState<string | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res) {
        onAuthSuccess(res.user, res.accessToken);
      }
    } catch (err: any) {
      console.error("Login failed:", err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleExportToGoogleSlides = async () => {
    if (!accessToken) {
      handleGoogleLogin();
      return;
    }

    setIsExportingSlides(true);
    setExportError(null);
    setExportSuccessUrl(null);

    try {
      const result = await createGoogleSlidesPresentation(deck, accessToken);
      setExportSuccessUrl(result.presentationUrl);
    } catch (err: any) {
      console.error("Export to Google Slides failed:", err);
      setExportError(err.message || "Failed to create Google Slides presentation.");
    } finally {
      setIsExportingSlides(false);
    }
  };

  const handleExportPPTX = () => {
    exportToPPTX(deck);
  };

  return (
    <header className="bg-[#0B0F14] border-b border-[#3DDC97]/10 text-[#E7EDF2] px-4 py-3 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo & Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-[#161B22] border border-[#3DDC97]/30 flex items-center justify-center text-[#3DDC97] shadow-lg shadow-[#3DDC97]/10">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif font-bold text-lg text-[#3DDC97] tracking-tight">
                {deck.title || "CyberSec Advisor"}
              </h1>
              <div className="flex items-center space-x-2 bg-[#161B22] border border-[#3DDC97]/30 px-3 py-0.5 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-[#3DDC97] animate-pulse" />
                <span className="text-[10px] font-mono text-[#3DDC97] uppercase tracking-widest font-semibold">
                  Local Instance Active
                </span>
              </div>
            </div>
            <p className="text-xs text-[#8CA0AF] hidden sm:block italic">
              A Local, Retrieval-Augmented Knowledge Assistant
            </p>
          </div>
        </div>

        {/* Actions & Export */}
        <div className="flex flex-wrap items-center gap-2">
          {/* AI Generator Button */}
          <button
            onClick={onOpenAiAssistModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#161B22] hover:bg-[#1E2632] text-[#3DDC97] border border-[#3DDC97]/30 rounded-xl transition-all"
            title="Generate or refine with Gemini AI"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Assist</span>
          </button>

          {/* Python Code Button */}
          <button
            onClick={onOpenPythonModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#161B22] hover:bg-[#1E2632] text-[#E7EDF2] border border-[#3DDC97]/10 rounded-xl transition-all"
            title="View python-pptx script"
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Python Script</span>
          </button>

          {/* Presenter Mode Button */}
          <button
            onClick={onOpenPresenterModal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#161B22] hover:bg-[#1E2632] text-indigo-300 border border-indigo-500/30 rounded-xl transition-all"
            title="Launch Presenter Mode with Teleprompter"
          >
            <Play className="w-3.5 h-3.5 text-indigo-400" />
            <span>Presenter Mode</span>
          </button>

          {/* Download PPTX Button */}
          <button
            onClick={handleExportPPTX}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#161B22] hover:bg-[#1E2632] text-[#E7EDF2] border border-[#3DDC97]/10 rounded-xl transition-all"
            title="Download PowerPoint (.pptx) file"
          >
            <Download className="w-3.5 h-3.5 text-[#3DDC97]" />
            <span>Download .pptx</span>
          </button>

          {/* Export to Google Slides Button */}
          <button
            onClick={handleExportToGoogleSlides}
            disabled={isExportingSlides}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold bg-[#3DDC97] hover:bg-[#34C787] text-[#0B0F14] rounded-xl transition-all shadow-md shadow-[#3DDC97]/10 disabled:opacity-50"
          >
            {isExportingSlides ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Exporting...</span>
              </>
            ) : (
              <>
                <Presentation className="w-3.5 h-3.5" />
                <span>Export to Google Slides</span>
              </>
            )}
          </button>

          {/* User Auth Section */}
          <div className="pl-2 border-l border-[#3DDC97]/10 flex items-center gap-2">
            {user ? (
              <div className="flex items-center gap-2">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || "User"}
                    className="w-7 h-7 rounded-full border border-[#3DDC97]/40"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-[#3DDC97]/20 text-[#3DDC97] border border-[#3DDC97]/30 flex items-center justify-center text-xs font-bold">
                    {user.email?.[0].toUpperCase() || "U"}
                  </div>
                )}
                <div className="hidden lg:block text-left">
                  <p className="text-[11px] font-medium text-[#E7EDF2] line-clamp-1">
                    {user.displayName || user.email}
                  </p>
                  <p className="text-[9px] text-[#3DDC97] font-mono">Google Slides Ready</p>
                </div>
                <button
                  onClick={async () => {
                    await logout();
                    onLogout();
                  }}
                  className="p-1.5 text-[#8CA0AF] hover:text-[#E7EDF2] hover:bg-[#161B22] rounded-lg"
                  title="Sign Out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleLogin}
                disabled={isLoggingIn}
                className="gsi-material-button inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#161B22] hover:bg-[#1E2632] text-[#E7EDF2] border border-[#3DDC97]/20 rounded-xl transition-all"
                title="Sign in with Google to enable Google Slides export"
              >
                {isLoggingIn ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-[#3DDC97]" />
                ) : (
                  <svg className="w-3.5 h-3.5" viewBox="0 0 48 48">
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    />
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    />
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    />
                  </svg>
                )}
                <span>Sign in</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Export Google Slides Banner if generated */}
      {exportSuccessUrl && (
        <div className="mt-2 bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 px-4 py-2 rounded-lg flex items-center justify-between text-xs max-w-7xl mx-auto animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>
              Presentation exported successfully to your Google Drive!
            </span>
          </div>
          <a
            href={exportSuccessUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium transition-all"
          >
            <span>Open in Google Slides</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      )}

      {/* Export Error Banner */}
      {exportError && (
        <div className="mt-2 bg-rose-950/80 border border-rose-500/40 text-rose-200 px-4 py-2 rounded-lg flex items-center justify-between text-xs max-w-7xl mx-auto">
          <span>{exportError}</span>
          <button
            onClick={() => setExportError(null)}
            className="text-rose-400 hover:text-rose-200 underline text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}
    </header>
  );
};
