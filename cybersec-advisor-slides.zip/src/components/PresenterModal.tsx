import React, { useState, useEffect } from "react";
import { Slide, DeckData } from "../types";
import { SlideCanvas } from "./SlideCanvas";
import {
  X,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  Maximize2,
  Minimize2,
  Clock,
  Volume2,
  AArrowUp,
  AArrowDown,
} from "lucide-react";

interface PresenterModalProps {
  deck: DeckData;
  initialSlideIndex: number;
  onClose: () => void;
}

export const PresenterModal: React.FC<PresenterModalProps> = ({
  deck,
  initialSlideIndex,
  onClose,
}) => {
  const [currentIndex, setCurrentIndex] = useState(initialSlideIndex);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [fontSize, setFontSize] = useState<"small" | "medium" | "large">(
    "medium"
  );

  // Timer effect
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setSecondsElapsed((prev) => prev + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "Space" || e.key === "PageDown") {
        e.preventDefault();
        if (currentIndex < deck.slides.length - 1) {
          setCurrentIndex((prev) => prev + 1);
        }
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        if (currentIndex > 0) {
          setCurrentIndex((prev) => prev - 1);
        }
      } else if (e.key === "Escape") {
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentIndex, deck.slides.length, onClose]);

  const currentSlide = deck.slides[currentIndex];
  const nextSlide = deck.slides[currentIndex + 1];

  const formatTimer = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins.toString().padStart(2, "0")}:${secs
      .toString()
      .padStart(2, "0")}`;
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B0F14] text-[#E7EDF2] flex flex-col font-sans select-none">
      {/* Top Controls Bar */}
      <div className="h-14 bg-[#161B22] border-b border-[#3DDC97]/10 px-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono font-bold bg-[#3DDC97]/10 text-[#3DDC97] border border-[#3DDC97]/30 px-3 py-1 rounded-full">
            <Clock className="w-3.5 h-3.5" />
            <span>{formatTimer(secondsElapsed)}</span>
          </div>

          <div className="flex items-center gap-1 text-[#8CA0AF] text-xs">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="p-1 hover:text-[#E7EDF2]"
              title={isTimerRunning ? "Pause timer" : "Start timer"}
            >
              {isTimerRunning ? (
                <Pause className="w-3.5 h-3.5" />
              ) : (
                <Play className="w-3.5 h-3.5" />
              )}
            </button>
            <button
              onClick={() => setSecondsElapsed(0)}
              className="p-1 hover:text-[#E7EDF2]"
              title="Reset timer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Center Slide Info */}
        <div className="text-xs text-[#8CA0AF] font-mono">
          Slide <span className="text-[#3DDC97] font-bold">{currentIndex + 1}</span> of{" "}
          {deck.slides.length}
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-3">
          {/* Script Font Size Adjust */}
          <div className="flex items-center gap-1 bg-[#0B0F14] p-1 rounded-xl border border-[#3DDC97]/20">
            <button
              onClick={() => setFontSize("small")}
              className={`p-1 text-xs rounded-lg ${
                fontSize === "small" ? "bg-[#161B22] text-[#3DDC97]" : "text-[#8CA0AF]"
              }`}
              title="Small text"
            >
              <AArrowDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setFontSize("medium")}
              className={`px-1.5 py-0.5 text-xs font-mono rounded-lg ${
                fontSize === "medium" ? "bg-[#161B22] text-[#3DDC97]" : "text-[#8CA0AF]"
              }`}
            >
              M
            </button>
            <button
              onClick={() => setFontSize("large")}
              className={`p-1 text-xs rounded-lg ${
                fontSize === "large" ? "bg-[#161B22] text-[#3DDC97]" : "text-[#8CA0AF]"
              }`}
              title="Large text"
            >
              <AArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-1.5 text-[#8CA0AF] hover:text-[#E7EDF2] bg-[#0B0F14] rounded-xl border border-[#3DDC97]/20"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4" />
            ) : (
              <Maximize2 className="w-4 h-4" />
            )}
          </button>

          <button
            onClick={onClose}
            className="p-1.5 text-[#8CA0AF] hover:text-rose-400 bg-[#0B0F14] rounded-xl border border-[#3DDC97]/20"
            title="Exit Presenter Mode"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Current Slide Canvas + Presenter Teleprompter */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 overflow-hidden">
        {/* Left: Live Slide View */}
        <div className="lg:col-span-7 flex flex-col justify-center items-center relative">
          <div className="w-full aspect-video max-h-[80vh] shadow-2xl rounded-3xl overflow-hidden border border-[#3DDC97]/20">
            <SlideCanvas
              slide={currentSlide}
              slideNumber={currentIndex + 1}
              totalSlides={deck.slides.length}
            />
          </div>

          {/* Nav Overlay */}
          <div className="mt-4 flex items-center gap-4">
            <button
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="px-4 py-2 bg-[#161B22] hover:bg-[#1E2632] disabled:opacity-40 text-[#E7EDF2] text-xs font-medium rounded-xl border border-[#3DDC97]/20 flex items-center gap-1 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() =>
                setCurrentIndex((prev) =>
                  Math.min(deck.slides.length - 1, prev + 1)
                )
              }
              disabled={currentIndex === deck.slides.length - 1}
              className="px-4 py-2 bg-[#3DDC97] hover:bg-[#34C787] disabled:opacity-40 text-[#0B0F14] text-xs font-semibold rounded-xl shadow-lg shadow-[#3DDC97]/10 flex items-center gap-1 transition-all"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right: Teleprompter & Speaker Notes */}
        <div className="lg:col-span-5 flex flex-col gap-4 overflow-hidden">
          {/* Teleprompter Script Card */}
          <div className="flex-1 bg-[#161B22] border border-[#3DDC97]/10 rounded-3xl p-5 flex flex-col overflow-hidden shadow-xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#3DDC97]/10 mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#3DDC97] font-semibold flex items-center gap-2">
                <Volume2 className="w-4 h-4" />
                Speaker Teleprompter Script
              </span>
              <span className="text-[10px] text-[#8CA0AF] font-mono">
                Press [Space] or [→] to advance
              </span>
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-4">
              <p
                className={`text-[#E7EDF2] font-sans leading-relaxed tracking-wide ${
                  fontSize === "small"
                    ? "text-sm"
                    : fontSize === "large"
                    ? "text-xl sm:text-2xl"
                    : "text-base sm:text-lg"
                }`}
              >
                {currentSlide.script ||
                  "No speaker notes entered for this slide."}
              </p>
            </div>
          </div>

          {/* Next Slide Preview */}
          <div className="h-40 bg-[#161B22] border border-[#3DDC97]/10 rounded-3xl p-4 flex flex-col justify-between">
            <p className="text-[11px] font-mono uppercase text-[#8CA0AF]">
              NEXT SLIDE ({currentIndex + 2} of {deck.slides.length})
            </p>
            {nextSlide ? (
              <div className="bg-[#0B0F14] p-3 rounded-2xl border border-[#3DDC97]/20">
                <p className="text-sm font-bold text-[#3DDC97] font-serif line-clamp-1">
                  {nextSlide.title}
                </p>
                <p className="text-xs text-[#8CA0AF] italic line-clamp-1 mt-0.5">
                  {nextSlide.subtitle || nextSlide.content?.[0]}
                </p>
              </div>
            ) : (
              <p className="text-xs text-[#8CA0AF] italic text-center my-auto">
                End of presentation deck
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
