import React, { useState } from "react";
import { DeckData } from "../types";
import { generatePythonCode } from "../lib/pythonExporter";
import { X, Copy, Check, Download, Code2 } from "lucide-react";

interface PythonScriptModalProps {
  deck: DeckData;
  onClose: () => void;
}

export const PythonScriptModal: React.FC<PythonScriptModalProps> = ({
  deck,
  onClose,
}) => {
  const pythonCode = generatePythonCode(deck);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([pythonCode], { type: "text/x-python" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${deck.title.replace(/[^a-zA-Z0-9_-]/g, "_")}_generator.py`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#161B22] border border-[#3DDC97]/20 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Modal Header */}
        <div className="p-4 border-b border-[#3DDC97]/10 flex items-center justify-between bg-[#0B0F14]">
          <div className="flex items-center gap-2 text-[#E7EDF2]">
            <Code2 className="w-5 h-5 text-amber-400" />
            <h3 className="font-semibold text-sm font-mono text-[#3DDC97]">
              python-pptx Script Generator
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-[#161B22] hover:bg-[#1E2632] text-[#E7EDF2] rounded-xl border border-[#3DDC97]/20 transition-all"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#3DDC97]" />
                  <span className="text-[#3DDC97]">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-[#8CA0AF]" />
                  <span>Copy Code</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-[#3DDC97] hover:bg-[#34C787] text-[#0B0F14] font-semibold rounded-xl transition-all shadow-md shadow-[#3DDC97]/10"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .py File</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-[#8CA0AF] hover:text-[#E7EDF2] rounded-xl"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 p-4 overflow-y-auto bg-[#0B0F14] text-xs font-mono text-[#E7EDF2]">
          <pre className="p-4 bg-[#161B22] rounded-2xl border border-[#3DDC97]/10 overflow-x-auto leading-relaxed select-text text-[#E7EDF2]">
            {pythonCode}
          </pre>
        </div>

        {/* Footer Note */}
        <div className="p-3 border-t border-[#3DDC97]/10 bg-[#0B0F14] text-[11px] text-[#8CA0AF] text-center font-mono">
          Requires python-pptx: <code className="text-[#3DDC97] bg-[#161B22] px-2 py-0.5 rounded-lg border border-[#3DDC97]/20">pip install python-pptx</code>
        </div>
      </div>
    </div>
  );
};
