import React, { useState, useEffect } from "react";
import { DeckData, Slide, UserProfile } from "./types";
import { initialDeck } from "./data/defaultDeck";
import { initAuth } from "./lib/firebase";
import { Navbar } from "./components/Navbar";
import { SlideCanvas } from "./components/SlideCanvas";
import { SlideList } from "./components/SlideList";
import { SlideEditor } from "./components/SlideEditor";
import { PresenterModal } from "./components/PresenterModal";
import { PythonScriptModal } from "./components/PythonScriptModal";
import { AiAssistModal } from "./components/AiAssistModal";
import { ChevronLeft, ChevronRight, Play, Layers, Sliders, Shield } from "lucide-react";

export default function App() {
  const [deck, setDeck] = useState<DeckData>(initialDeck);
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  // Modal States
  const [showPresenterModal, setShowPresenterModal] = useState(false);
  const [showPythonModal, setShowPythonModal] = useState(false);
  const [showAiAssistModal, setShowAiAssistModal] = useState(false);

  // Mobile sidebar view toggle ('slides' | 'editor')
  const [mobileTab, setMobileTab] = useState<"slides" | "editor">("slides");

  // Initialize Firebase Auth listener
  useEffect(() => {
    initAuth(
      (authUser, token) => {
        setUser({
          uid: authUser.uid,
          displayName: authUser.displayName,
          email: authUser.email,
          photoURL: authUser.photoURL,
        });
        setAccessToken(token);
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );
  }, []);

  const activeSlide = deck.slides[activeSlideIndex] || deck.slides[0];

  const handleUpdateSlide = (updatedSlide: Slide) => {
    const updatedSlides = [...deck.slides];
    updatedSlides[activeSlideIndex] = updatedSlide;
    setDeck({ ...deck, slides: updatedSlides });
  };

  const handleAddSlide = () => {
    const newSlide: Slide = {
      id: `slide-${Date.now()}`,
      title: "New Security Analysis Slide",
      subtitle: "Subtitle description of takeaway",
      content: [
        "First technical point",
        "Second supporting evidence or measurement",
      ],
      visual: "Graphic suggestion or flowchart diagram",
      script: "Speaker notes for this new slide.",
      layoutType: "standard",
    };

    const newSlides = [...deck.slides, newSlide];
    setDeck({ ...deck, slides: newSlides });
    setActiveSlideIndex(newSlides.length - 1);
  };

  const handleDuplicateSlide = (index: number) => {
    const slideToDup = deck.slides[index];
    const duplicated: Slide = {
      ...slideToDup,
      id: `slide-${Date.now()}`,
      title: `${slideToDup.title} (Copy)`,
    };

    const newSlides = [...deck.slides];
    newSlides.splice(index + 1, 0, duplicated);
    setDeck({ ...deck, slides: newSlides });
    setActiveSlideIndex(index + 1);
  };

  const handleDeleteSlide = (index: number) => {
    if (deck.slides.length <= 1) return;
    const newSlides = deck.slides.filter((_, i) => i !== index);
    setDeck({ ...deck, slides: newSlides });
    if (activeSlideIndex >= newSlides.length) {
      setActiveSlideIndex(newSlides.length - 1);
    }
  };

  const handleMoveSlide = (index: number, direction: "up" | "down") => {
    const targetIndex = direction === "up" ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= deck.slides.length) return;

    const newSlides = [...deck.slides];
    const [moved] = newSlides.splice(index, 1);
    newSlides.splice(targetIndex, 0, moved);

    setDeck({ ...deck, slides: newSlides });
    setActiveSlideIndex(targetIndex);
  };

  return (
    <div className="min-h-screen bg-[#0B0F14] text-[#E7EDF2] flex flex-col font-sans select-none overflow-hidden">
      {/* Top Navigation */}
      <Navbar
        user={user}
        accessToken={accessToken}
        deck={deck}
        onOpenPythonModal={() => setShowPythonModal(true)}
        onOpenPresenterModal={() => setShowPresenterModal(true)}
        onOpenAiAssistModal={() => setShowAiAssistModal(true)}
        onAuthSuccess={(u, token) => {
          setUser({
            uid: u.uid,
            displayName: u.displayName,
            email: u.email,
            photoURL: u.photoURL,
          });
          setAccessToken(token);
        }}
        onLogout={() => {
          setUser(null);
          setAccessToken(null);
        }}
      />

      {/* Main Studio Body Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden relative">
        {/* Left Sidebar: Slide List (3 Columns on Large Screens) */}
        <div className="hidden lg:block lg:col-span-3 h-[calc(100vh-61px)]">
          <SlideList
            slides={deck.slides}
            activeSlideIndex={activeSlideIndex}
            onSelectSlide={(idx) => setActiveSlideIndex(idx)}
            onAddSlide={handleAddSlide}
            onDuplicateSlide={handleDuplicateSlide}
            onDeleteSlide={handleDeleteSlide}
            onMoveSlide={handleMoveSlide}
          />
        </div>

        {/* Mobile View Toggle Tabs */}
        <div className="lg:hidden flex border-b border-[#3DDC97]/10 bg-[#0B0F14] p-1.5 justify-around text-xs font-medium">
          <button
            onClick={() => setMobileTab("slides")}
            className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 ${
              mobileTab === "slides"
                ? "bg-[#161B22] text-[#3DDC97] border border-[#3DDC97]/30"
                : "text-[#8CA0AF]"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Slide Deck ({deck.slides.length})</span>
          </button>
          <button
            onClick={() => setMobileTab("editor")}
            className={`flex-1 py-2 rounded-xl flex items-center justify-center gap-1.5 ${
              mobileTab === "editor"
                ? "bg-[#161B22] text-[#3DDC97] border border-[#3DDC97]/30"
                : "text-[#8CA0AF]"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Edit Slide</span>
          </button>
        </div>

        {/* Mobile Slide List Drawer */}
        {mobileTab === "slides" && (
          <div className="lg:hidden block h-[240px] overflow-y-auto border-b border-[#3DDC97]/10">
            <SlideList
              slides={deck.slides}
              activeSlideIndex={activeSlideIndex}
              onSelectSlide={(idx) => {
                setActiveSlideIndex(idx);
                setMobileTab("editor");
              }}
              onAddSlide={handleAddSlide}
              onDuplicateSlide={handleDuplicateSlide}
              onDeleteSlide={handleDeleteSlide}
              onMoveSlide={handleMoveSlide}
            />
          </div>
        )}

        {/* Middle Stage: Slide Canvas Preview (6 Columns on Large Screens) */}
        <div className="lg:col-span-6 bg-[#0B0F14] p-4 sm:p-6 flex flex-col justify-between items-center h-[calc(100vh-61px)] overflow-y-auto">
          {/* Top Bar Info */}
          <div className="w-full flex items-center justify-between text-xs text-[#8CA0AF] font-mono mb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#3DDC97] animate-pulse" />
              <span>Editing Slide {activeSlideIndex + 1} of {deck.slides.length}</span>
            </div>
            <button
              onClick={() => setShowPresenterModal(true)}
              className="flex items-center gap-1 text-[#3DDC97] hover:underline font-mono"
            >
              <Play className="w-3 h-3" />
              <span>Present Fullscreen</span>
            </button>
          </div>

          {/* Slide 16:9 Stage */}
          <div className="w-full max-w-4xl aspect-video my-auto shadow-2xl rounded-3xl overflow-hidden border border-[#3DDC97]/20 transform transition-all hover:scale-[1.002]">
            <SlideCanvas
              slide={activeSlide}
              slideNumber={activeSlideIndex + 1}
              totalSlides={deck.slides.length}
            />
          </div>

          {/* Bottom Navigation Buttons */}
          <div className="w-full max-w-4xl flex items-center justify-between mt-3 pt-3 border-t border-[#3DDC97]/10">
            <button
              onClick={() => setActiveSlideIndex((prev) => Math.max(0, prev - 1))}
              disabled={activeSlideIndex === 0}
              className="px-3.5 py-1.5 bg-[#161B22] hover:bg-[#1E2632] disabled:opacity-30 text-[#E7EDF2] text-xs font-medium rounded-xl border border-[#3DDC97]/20 flex items-center gap-1 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Prev Slide</span>
            </button>

            <span className="text-xs text-[#8CA0AF] font-mono hidden sm:inline">
              Use Presenter Mode for teleprompter view
            </span>

            <button
              onClick={() =>
                setActiveSlideIndex((prev) =>
                  Math.min(deck.slides.length - 1, prev + 1)
                )
              }
              disabled={activeSlideIndex === deck.slides.length - 1}
              className="px-3.5 py-1.5 bg-[#3DDC97] hover:bg-[#34C787] disabled:opacity-30 text-[#0B0F14] text-xs font-semibold rounded-xl shadow-md shadow-[#3DDC97]/10 flex items-center gap-1 transition-all"
            >
              <span>Next Slide</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Right Sidebar: Slide Editor (3 Columns on Large Screens) */}
        <div className={`lg:col-span-3 h-[calc(100vh-61px)] ${mobileTab === "editor" ? "block" : "hidden lg:block"}`}>
          <SlideEditor
            slide={activeSlide}
            onUpdateSlide={handleUpdateSlide}
          />
        </div>
      </div>

      {/* Modals */}
      {showPresenterModal && (
        <PresenterModal
          deck={deck}
          initialSlideIndex={activeSlideIndex}
          onClose={() => setShowPresenterModal(false)}
        />
      )}

      {showPythonModal && (
        <PythonScriptModal
          deck={deck}
          onClose={() => setShowPythonModal(false)}
        />
      )}

      {showAiAssistModal && (
        <AiAssistModal
          onGenerateNewDeck={(newDeck) => {
            setDeck(newDeck);
            setActiveSlideIndex(0);
          }}
          onClose={() => setShowAiAssistModal(false)}
        />
      )}
    </div>
  );
}
