export type LayoutType =
  | "title"
  | "agenda"
  | "standard"
  | "architecture"
  | "features"
  | "results"
  | "roadmap"
  | "conclusion"
  | "qa";

export interface Slide {
  id: string;
  title: string;
  subtitle: string;
  content: string[];
  visual: string;
  script: string;
  layoutType: LayoutType;
}

export interface DeckData {
  title: string;
  subtitle: string;
  slides: Slide[];
}

export interface UserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
}
