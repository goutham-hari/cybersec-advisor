import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initializer for Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getAIClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "CyberSec Advisor Presentation API" });
});

// AI Refine Endpoint (Refines slides, speaker notes, or visual suggestions)
app.post("/api/ai/refine", async (req, res) => {
  try {
    const { action, slide, customPrompt } = req.body;
    const ai = getAIClient();

    let systemInstruction = "You are a expert cybersecurity researcher and technical presentation designer.";
    let userPrompt = "";

    if (action === "refine_bullets") {
      userPrompt = `Refine and improve these slide bullet points for a cybersecurity research deck titled "${slide.title}".
Current Bullets:
${(slide.content || []).join("\n")}

Provide 3-5 punchy, highly technical, yet readable bullet points. Return ONLY a JSON array of strings, e.g. ["Point 1", "Point 2"].`;
    } else if (action === "generate_script") {
      userPrompt = `Write a compelling, professional speaker script/notes for the slide titled "${slide.title}" (Subtitle: "${slide.subtitle}").
Key points covered:
${(slide.content || []).join("\n")}

Write a 3-4 sentence spoken script in first-person ("Today, I am excited...", "As you can see..."). Return ONLY plain text for the script without markdown code blocks.`;
    } else if (action === "suggest_visual") {
      userPrompt = `Suggest an effective technical diagram or visual layout description for a slide titled "${slide.title}" with key points:
${(slide.content || []).join("\n")}

Provide a concise 1-2 sentence description of the recommended visual or diagram layout. Return plain text only.`;
    } else if (action === "custom") {
      userPrompt = `Slide Title: ${slide.title}
Subtitle: ${slide.subtitle}
Content: ${(slide.content || []).join("; ")}
User Request: ${customPrompt}

Provide helpful improvements or generated content according to the user request.`;
    } else {
      return res.status(400).json({ error: "Invalid action" });
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const resultText = response.text?.trim() || "";
    return res.json({ result: resultText });
  } catch (error: any) {
    console.error("AI refinement error:", error);
    return res.status(500).json({ error: error.message || "Failed to process AI request" });
  }
});

// AI Slide Deck Generator
app.post("/api/ai/generate-deck", async (req, res) => {
  try {
    const { topic } = req.body;
    const ai = getAIClient();

    const userPrompt = `Generate a structured presentation deck about: "${topic}".
Return JSON with the structure:
{
  "title": "Main Deck Title",
  "slides": [
    {
      "title": "Slide Title",
      "subtitle": "Slide Subtitle / Main Takeaway",
      "content": ["Bullet 1", "Bullet 2", "Bullet 3"],
      "visual": "Description of visual diagram",
      "script": "Full speaker notes for this slide",
      "layoutType": "standard" // choice from: "title", "standard", "agenda", "architecture", "features", "results", "roadmap", "conclusion", "qa"
    }
  ]
}
Include 5-8 slides covering Title, Overview/Problem, Solution/Architecture, Methodology/Features, Results/Metrics, and Conclusion/Q&A. Return strictly valid JSON.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userPrompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    const resultText = response.text || "{}";
    const parsed = JSON.parse(resultText);
    return res.json(parsed);
  } catch (error: any) {
    console.error("AI deck generation error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate slide deck" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
